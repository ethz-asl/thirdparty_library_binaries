Array3d v(8,27,64);
cout << v.pow(0.333333) << endl;
